const Discord = require("discord.js")
const db = require("quick.db")

module.exports = {
    name: "a", // Coloque o nome do comando do arquivo
    aliases: [""], // Coloque sinônimos aqui

    run: async(client, message, args) => {

       message.channel.send(``)
        
    }
}